import { db } from "./index";
import * as schema from "@shared/schema";
import { createHash } from "crypto";

async function seed() {
  try {
    console.log("Seeding database...");

    // Create categories
    const categories = [
      { name: "Electronics", description: "Electronic gadgets and devices", image: "https://images.unsplash.com/photo-1498049794561-7780e7231661?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" },
      { name: "Clothing", description: "Fashion and apparel items", image: "https://images.unsplash.com/photo-1445205170230-053b83016050?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" },
      { name: "Home & Kitchen", description: "Furniture and kitchen appliances", image: "https://images.unsplash.com/photo-1556911220-e15b29be8c8f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" },
      { name: "Books", description: "Books, magazines, and publications", image: "https://images.unsplash.com/photo-1495446815901-a7297e633e8d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" },
      { name: "Beauty", description: "Beauty and personal care products", image: "https://images.unsplash.com/photo-1571781926291-c477ebfd024b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" },
    ];

    const existingCategories = await db.query.categories.findMany();
    
    if (existingCategories.length === 0) {
      console.log("Creating categories...");
      await db.insert(schema.categories).values(categories);
    } else {
      console.log("Categories already exist. Skipping...");
    }

    // Create suppliers
    const suppliers = [
      { name: "TechDirect", email: "support@techdirect.com", phone: "555-123-4567", address: "123 Tech Street, Silicon Valley, CA" },
      { name: "FashionHub", email: "info@fashionhub.com", phone: "555-987-6543", address: "456 Fashion Ave, New York, NY" },
      { name: "HomeEssentials", email: "contact@homeessentials.com", phone: "555-456-7890", address: "789 Home Blvd, Chicago, IL" },
    ];

    const existingSuppliers = await db.query.suppliers.findMany();
    
    if (existingSuppliers.length === 0) {
      console.log("Creating suppliers...");
      await db.insert(schema.suppliers).values(suppliers);
    } else {
      console.log("Suppliers already exist. Skipping...");
    }

    // Get created categories and suppliers for reference
    const createdCategories = await db.query.categories.findMany();
    const createdSuppliers = await db.query.suppliers.findMany();

    // Create products
    const products = [
      // Electronics products
      {
        name: "Wireless Headphones",
        description: "High-quality wireless headphones with noise cancellation and 20-hour battery life.",
        price: "129.99",
        image: "https://images.unsplash.com/photo-1583394838336-acd977736f90?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        gallery: JSON.stringify([
          "https://images.unsplash.com/photo-1583394838336-acd977736f90?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
          "https://images.unsplash.com/photo-1484704849700-f032a568e944?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
        ]),
        inventory: 50,
        categoryId: createdCategories.find(c => c.name === "Electronics")?.id || 1,
        supplierId: createdSuppliers.find(s => s.name === "TechDirect")?.id || 1,
        isDropshipped: true,
      },
      {
        name: "Smart Watch",
        description: "Feature-rich smartwatch with health tracking, notifications, and a 3-day battery life.",
        price: "199.99",
        compareAtPrice: "249.99",
        image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        gallery: JSON.stringify([
          "https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
          "https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
        ]),
        inventory: 35,
        categoryId: createdCategories.find(c => c.name === "Electronics")?.id || 1,
        supplierId: createdSuppliers.find(s => s.name === "TechDirect")?.id || 1,
        isDropshipped: true,
      },
      // Clothing products
      {
        name: "Classic T-Shirt",
        description: "Comfortable and stylish 100% cotton t-shirt that goes with everything.",
        price: "19.99",
        image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        gallery: JSON.stringify([
          "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
          "https://images.unsplash.com/photo-1503341504253-dff4815485f1?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
        ]),
        inventory: 100,
        categoryId: createdCategories.find(c => c.name === "Clothing")?.id || 2,
        supplierId: createdSuppliers.find(s => s.name === "FashionHub")?.id || 2,
        isDropshipped: true,
      },
      {
        name: "Slim Fit Jeans",
        description: "Modern slim fit jeans made from premium denim for durability and style.",
        price: "49.99",
        compareAtPrice: "69.99",
        image: "https://images.unsplash.com/photo-1542272604-787c3835535d?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        gallery: JSON.stringify([
          "https://images.unsplash.com/photo-1542272604-787c3835535d?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
          "https://images.unsplash.com/photo-1582552938357-32b906df40cb?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
        ]),
        inventory: 80,
        categoryId: createdCategories.find(c => c.name === "Clothing")?.id || 2,
        supplierId: createdSuppliers.find(s => s.name === "FashionHub")?.id || 2,
        isDropshipped: false,
      },
      // Home & Kitchen products
      {
        name: "Coffee Maker",
        description: "Programmable 12-cup coffee maker with auto-shutoff and brew strength control.",
        price: "59.99",
        image: "https://images.unsplash.com/photo-1564585222527-c2777a5bc6cb?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        gallery: JSON.stringify([
          "https://images.unsplash.com/photo-1564585222527-c2777a5bc6cb?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
          "https://images.unsplash.com/photo-1522410030984-501065f72957?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
        ]),
        inventory: 40,
        categoryId: createdCategories.find(c => c.name === "Home & Kitchen")?.id || 3,
        supplierId: createdSuppliers.find(s => s.name === "HomeEssentials")?.id || 3,
        isDropshipped: false,
      },
      {
        name: "Knife Set",
        description: "Professional 15-piece knife set with acrylic stand and built-in sharpener.",
        price: "89.99",
        compareAtPrice: "129.99",
        image: "https://images.unsplash.com/photo-1566454825481-11d9073de252?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        gallery: JSON.stringify([
          "https://images.unsplash.com/photo-1566454825481-11d9073de252?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
          "https://images.unsplash.com/photo-1575312064761-49cfa4cc4d39?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
        ]),
        inventory: 25,
        categoryId: createdCategories.find(c => c.name === "Home & Kitchen")?.id || 3,
        supplierId: createdSuppliers.find(s => s.name === "HomeEssentials")?.id || 3,
        isDropshipped: true,
      },
    ];

    const existingProducts = await db.query.products.findMany();
    
    if (existingProducts.length === 0) {
      console.log("Creating products...");
      await db.insert(schema.products).values(products);
    } else {
      console.log("Products already exist. Skipping...");
    }

    // Create coupons
    const today = new Date();
    const nextMonth = new Date(today);
    nextMonth.setMonth(nextMonth.getMonth() + 1);
    
    const coupons = [
      {
        code: "WELCOME15",
        description: "15% off on your first order",
        discountType: "percentage",
        discountValue: "15.00",
        minimumPurchase: "50.00",
        startsAt: today,
        expiresAt: nextMonth,
        usageLimit: 1000,
      },
      {
        code: "SAVE10",
        description: "10% discount on all products",
        discountType: "percentage",
        discountValue: "10.00",
        minimumPurchase: null,
        startsAt: today,
        expiresAt: nextMonth,
        usageLimit: null,
      },
      {
        code: "FREESHIP",
        description: "Free shipping on orders over $75",
        discountType: "fixed",
        discountValue: "10.00",
        minimumPurchase: "75.00",
        startsAt: today,
        expiresAt: nextMonth,
        usageLimit: null,
      },
    ];

    const existingCoupons = await db.query.coupons.findMany();
    
    if (existingCoupons.length === 0) {
      console.log("Creating coupons...");
      await db.insert(schema.coupons).values(coupons);
    } else {
      console.log("Coupons already exist. Skipping...");
    }

    // Create special offers
    const nextWeek = new Date(today);
    nextWeek.setDate(nextWeek.getDate() + 7);
    
    const specialOffers = [
      {
        title: "Flash Sale: 25% Off Electronics",
        description: "Get 25% off on all electronics for the next 7 days!",
        image: "https://images.unsplash.com/photo-1550009158-9ebf69173e03?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
        discountType: "percentage",
        discountValue: "25.00",
        startsAt: today,
        endsAt: nextWeek,
      },
      {
        title: "Buy One, Get One 50% Off",
        description: "Buy any clothing item and get another at 50% off!",
        image: "https://images.unsplash.com/photo-1607083206968-13611e3d76db?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
        discountType: "percentage",
        discountValue: "50.00",
        startsAt: today,
        endsAt: nextWeek,
      },
      {
        title: "Summer Clearance: Up to 60% Off",
        description: "End of season clearance with discounts up to 60% off select items",
        image: "https://images.unsplash.com/photo-1445205170230-053b83016050?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
        discountType: "percentage",
        discountValue: "60.00",
        startsAt: today,
        endsAt: nextWeek,
      },
    ];

    const existingOffers = await db.query.specialOffers.findMany();
    
    if (existingOffers.length === 0) {
      console.log("Creating special offers...");
      const insertedOffers = await db.insert(schema.specialOffers).values(specialOffers).returning();
      
      // Link products to offers
      const allProducts = await db.query.products.findMany();
      
      // Electronics offer
      const electronicsProducts = allProducts.filter(p => p.categoryId === createdCategories.find(c => c.name === "Electronics")?.id);
      const electronicsOffer = insertedOffers.find(o => o.title.includes("Electronics"));
      
      if (electronicsOffer && electronicsProducts.length > 0) {
        await db.insert(schema.offerProducts).values(
          electronicsProducts.map(p => ({
            offerId: electronicsOffer.id,
            productId: p.id
          }))
        );
      }
      
      // Clothing offer
      const clothingProducts = allProducts.filter(p => p.categoryId === createdCategories.find(c => c.name === "Clothing")?.id);
      const clothingOffer = insertedOffers.find(o => o.title.includes("Buy One"));
      
      if (clothingOffer && clothingProducts.length > 0) {
        await db.insert(schema.offerProducts).values(
          clothingProducts.map(p => ({
            offerId: clothingOffer.id,
            productId: p.id
          }))
        );
      }
      
      // Summer clearance
      const clearanceOffer = insertedOffers.find(o => o.title.includes("Clearance"));
      if (clearanceOffer) {
        await db.insert(schema.offerProducts).values(
          allProducts.map(p => ({
            offerId: clearanceOffer.id,
            productId: p.id
          }))
        );
      }
    } else {
      console.log("Special offers already exist. Skipping...");
    }

    // Create a test user
    const existingUsers = await db.query.users.findMany();
    
    if (existingUsers.length === 0) {
      console.log("Creating test user...");
      const hashedPassword = createHash("sha256").update("password123").digest("hex");
      
      await db.insert(schema.users).values({
        username: "testuser",
        password: hashedPassword,
        email: "test@example.com",
        fullName: "Test User",
        address: "123 Test St",
        city: "Test City",
        state: "TS",
        zipCode: "12345",
      });
    } else {
      console.log("Users already exist. Skipping...");
    }

    console.log("Seeding completed successfully!");
  } catch (error) {
    console.error("Error during seeding:", error);
  }
}

seed();
