import React, { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { ProductGrid } from "@/components/product/ProductGrid";
import { OfferBanner } from "@/components/coupon/OfferBanner";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { useMobile } from "@/hooks/use-mobile";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Filter, SlidersHorizontal } from "lucide-react";

// Define interfaces for type safety
interface Category {
  id: number;
  name: string;
  description?: string;
  image?: string;
}

interface Supplier {
  id: number;
  name: string;
  email: string;
  phone: string;
  address: string;
}

export default function ProductsPage() {
  const [location, setLocation] = useLocation();
  const isMobile = useMobile();
  
  // Get URL parameters
  const searchParams = new URLSearchParams(location.split("?")[1] || "");
  const initialCategoryId = searchParams.get("categoryId");
  const initialSearch = searchParams.get("search");
  const initialIsDropshipped = searchParams.get("isDropshipped");
  const initialSupplierId = searchParams.get("supplierId");
  const initialMinPrice = searchParams.get("minPrice");
  const initialMaxPrice = searchParams.get("maxPrice");
  
  // Filter states
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategoryId || "");
  const [isDropshipped, setIsDropshipped] = useState<boolean>(initialIsDropshipped === "true");
  const [priceRange, setPriceRange] = useState<[number, number]>([
    initialMinPrice ? parseInt(initialMinPrice) : 0,
    initialMaxPrice ? parseInt(initialMaxPrice) : 1000
  ]);
  const [selectedSupplier, setSelectedSupplier] = useState<string>(initialSupplierId || "");
  const [searchQuery, setSearchQuery] = useState<string>(initialSearch || "");
  const [page, setPage] = useState<number>(1);
  const [sortBy, setSortBy] = useState<string>("createdAt");
  const [sortDirection, setSortDirection] = useState<string>("desc");
  
  // Fetch categories
  const { data: categories } = useQuery<Category[]>({
    queryKey: ["/api/categories"]
  });
  
  // Fetch suppliers
  const { data: suppliers } = useQuery<Supplier[]>({
    queryKey: ["/api/suppliers"]
  });
  
  // Update URL when filters change
  useEffect(() => {
    const params = new URLSearchParams();
    
    if (selectedCategory) params.append("categoryId", selectedCategory);
    if (searchQuery) params.append("search", searchQuery);
    if (isDropshipped) params.append("isDropshipped", "true");
    if (selectedSupplier) params.append("supplierId", selectedSupplier);
    if (priceRange[0] > 0) params.append("minPrice", priceRange[0].toString());
    if (priceRange[1] < 1000) params.append("maxPrice", priceRange[1].toString());
    
    // Don't add page to URL if it's 1 (default)
    if (page > 1) params.append("page", page.toString());
    
    const query = params.toString();
    setLocation(`/products${query ? `?${query}` : ""}`, { replace: true });
  }, [selectedCategory, searchQuery, isDropshipped, selectedSupplier, priceRange, page, setLocation]);
  
  // Reset page when filters change
  useEffect(() => {
    setPage(1);
  }, [selectedCategory, searchQuery, isDropshipped, selectedSupplier, priceRange]);
  
  // Get search query from URL on initial load
  useEffect(() => {
    const searchParams = new URLSearchParams(location.split("?")[1] || "");
    const newSearch = searchParams.get("search");
    
    if (newSearch) {
      setSearchQuery(newSearch);
    }
  }, [location]);
  
  const handleCategoryChange = (value: string) => {
    setSelectedCategory(value === "all_categories" ? "" : value);
  };
  
  const handleSupplierChange = (value: string) => {
    setSelectedSupplier(value === "all_suppliers" ? "" : value);
  };
  
  const handlePriceChange = (values: number[]) => {
    setPriceRange([values[0], values[1]]);
  };
  
  const handleSortChange = (value: string) => {
    switch (value) {
      case "price_asc":
        setSortBy("price");
        setSortDirection("asc");
        break;
      case "price_desc":
        setSortBy("price");
        setSortDirection("desc");
        break;
      case "name_asc":
        setSortBy("name");
        setSortDirection("asc");
        break;
      case "newest":
      default:
        setSortBy("createdAt");
        setSortDirection("desc");
        break;
    }
  };
  
  const handleResetFilters = () => {
    setSelectedCategory("");
    setIsDropshipped(false);
    setPriceRange([0, 1000]);
    setSelectedSupplier("");
    setSortBy("createdAt");
    setSortDirection("desc");
    
    // Update URL to reflect reset filters
    setLocation("/products", { replace: true });
  };
  
  const formatPriceLabel = (value: number) => {
    return `$${value}`;
  };
  
  // Filters component to avoid repetition
  const FiltersContent = () => (
    <div className="space-y-6">
      {/* Categories filter */}
      <div>
        <h3 className="font-medium mb-3">Categories</h3>
        <Select value={selectedCategory} onValueChange={handleCategoryChange}>
          <SelectTrigger>
            <SelectValue placeholder="All Categories" />
          </SelectTrigger>
          <SelectContent>
            <SelectGroup>
              <SelectItem value="all_categories">All Categories</SelectItem>
              {Array.isArray(categories) && categories.map((category) => (
                <SelectItem key={category.id} value={category.id.toString()}>
                  {category.name}
                </SelectItem>
              ))}
            </SelectGroup>
          </SelectContent>
        </Select>
      </div>
      
      {/* Price range filter */}
      <div>
        <h3 className="font-medium mb-3">Price Range</h3>
        <div className="pl-2 pr-2">
          <Slider
            value={priceRange}
            min={0}
            max={1000}
            step={5}
            minStepsBetweenThumbs={1}
            onValueChange={handlePriceChange}
          />
          <div className="flex justify-between mt-2 text-sm text-gray-600">
            <span>{formatPriceLabel(priceRange[0])}</span>
            <span>{formatPriceLabel(priceRange[1])}</span>
          </div>
        </div>
      </div>
      
      {/* Dropshipped filter */}
      <div>
        <div className="flex items-center space-x-2">
          <Checkbox
            id="dropshipped"
            checked={isDropshipped}
            onCheckedChange={(checked) => setIsDropshipped(checked as boolean)}
          />
          <Label htmlFor="dropshipped">Show Dropshipped Only</Label>
        </div>
      </div>
      
      {/* Supplier filter */}
      {Array.isArray(suppliers) && suppliers.length > 0 && (
        <div>
          <h3 className="font-medium mb-3">Supplier</h3>
          <Select value={selectedSupplier} onValueChange={handleSupplierChange}>
            <SelectTrigger>
              <SelectValue placeholder="All Suppliers" />
            </SelectTrigger>
            <SelectContent>
              <SelectGroup>
                <SelectItem value="all_suppliers">All Suppliers</SelectItem>
                {suppliers.map((supplier) => (
                  <SelectItem key={supplier.id} value={supplier.id.toString()}>
                    {supplier.name}
                  </SelectItem>
                ))}
              </SelectGroup>
            </SelectContent>
          </Select>
        </div>
      )}
      
      {/* Reset filters button */}
      <Button 
        variant="outline" 
        className="w-full"
        onClick={handleResetFilters}
      >
        Clear Filters
      </Button>
    </div>
  );
  
  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-gray-50">
        {/* Special Offers Banner */}
        <section className="container mx-auto px-4 py-4">
          <OfferBanner />
        </section>
        
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold">All Products</h1>
            
            {/* Sort dropdown */}
            <div className="flex items-center space-x-2">
              {isMobile && (
                <Sheet>
                  <SheetTrigger asChild>
                    <Button variant="outline" size="sm">
                      <Filter className="h-4 w-4 mr-2" />
                      Filters
                    </Button>
                  </SheetTrigger>
                  <SheetContent>
                    <h2 className="font-bold text-lg mb-4">Filters</h2>
                    <FiltersContent />
                  </SheetContent>
                </Sheet>
              )}
              
              <Select defaultValue="newest" onValueChange={handleSortChange}>
                <SelectTrigger className="w-[160px]">
                  <SlidersHorizontal className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Sort By" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Newest</SelectItem>
                  <SelectItem value="price_asc">Price: Low to High</SelectItem>
                  <SelectItem value="price_desc">Price: High to Low</SelectItem>
                  <SelectItem value="name_asc">Name: A to Z</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Filters - Desktop */}
            {!isMobile && (
              <div className="lg:col-span-1">
                <Card>
                  <CardHeader>
                    <CardTitle>Filters</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <FiltersContent />
                  </CardContent>
                </Card>
              </div>
            )}
            
            {/* Products grid */}
            <div className="lg:col-span-3">
              <ProductGrid
                categoryId={selectedCategory ? parseInt(selectedCategory) : undefined}
                search={searchQuery}
                isDropshipped={isDropshipped}
                supplierId={selectedSupplier ? parseInt(selectedSupplier) : undefined}
                page={page}
                setPage={setPage}
              />
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
