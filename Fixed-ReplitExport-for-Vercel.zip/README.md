# Mercatus E-Commerce Platform

A modern e-commerce platform with dropshipping capabilities, built with React, Express, and PostgreSQL.

## Features

- Modern UI with smooth scrolling animations
- Product catalog with category filtering
- Shopping cart functionality
- User authentication
- Dropshipping system
- Coupon and special offers
- Responsive design for all devices

## Tech Stack

- **Frontend**: React with Vite
- **Backend**: Express.js
- **Database**: PostgreSQL with Drizzle ORM
- **Styling**: Tailwind CSS with shadcn/ui
- **Authentication**: Passport.js
- **Routing**: wouter (lightweight router)
- **API Handling**: TanStack Query

## Deployment Instructions

### Local Development

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd mercatus-ecommerce
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create a `.env` file based on `.env.example` and add your database credentials.

4. Set up the database:
   ```bash
   npm run db:push
   npm run db:seed
   ```

5. Start the development server:
   ```bash
   npm run dev
   ```

### GitHub Deployment

1. Create a new GitHub repository.

2. Push your code to GitHub:
   ```bash
   git remote add origin <your-github-repo-url>
   git branch -M main
   git push -u origin main
   ```

### Vercel Deployment

1. Sign up for a [Vercel account](https://vercel.com/signup) if you don't have one.

2. Install the Vercel CLI:
   ```bash
   npm i -g vercel
   ```

3. Login to Vercel:
   ```bash
   vercel login
   ```

4. Deploy to Vercel:
   ```bash
   vercel
   ```

5. For production deployment:
   ```bash
   vercel --prod
   ```

6. Configure environment variables in the Vercel dashboard:
   - Go to your project in Vercel
   - Navigate to Settings > Environment Variables
   - Add all variables from your `.env.example` file

## Database Configuration

The application uses PostgreSQL with the Drizzle ORM. You'll need to set up a PostgreSQL database and configure the connection using the following environment variables:

- `DATABASE_URL`: The full connection URL
- `PGHOST`: PostgreSQL host
- `PGPORT`: PostgreSQL port
- `PGDATABASE`: Database name
- `PGUSER`: Database user
- `PGPASSWORD`: Database password

For Vercel deployment, you can use services like [Neon](https://neon.tech) or [Supabase](https://supabase.com) for PostgreSQL hosting.

## Project Structure

```
├── api/                  # Vercel serverless functions
├── client/               # Frontend React application
│   ├── src/              # Source files
│   │   ├── components/   # React components
│   │   ├── context/      # React context providers
│   │   ├── hooks/        # Custom React hooks
│   │   ├── lib/          # Utility functions
│   │   ├── pages/        # Page components
│   │   ├── App.tsx       # Main app component
│   │   └── main.tsx      # Entry point
├── db/                   # Database related files
│   ├── index.ts          # Database connection
│   └── seed.ts           # Seed data
├── server/               # Express server
│   ├── index.ts          # Server entry point
│   └── routes.ts         # API routes
├── shared/               # Shared types and schemas
│   └── schema.ts         # Database schema
└── vercel.json           # Vercel configuration
```

## License

MIT